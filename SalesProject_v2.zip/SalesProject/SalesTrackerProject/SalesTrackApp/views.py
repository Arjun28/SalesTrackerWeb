from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
from SalesTrackApp.models import SalesPerson, ShopAddress, SalesTracker

from pprint import pprint

def index(request):
    return HttpResponse("Welcome....")

def SalesTrack(request):
    return render(request, 'SalesTrackApp/SalesTracker.html')

@csrf_exempt
def GETNames(request):
    allSalesPersons = [s_person.name for s_person in SalesPerson.objects.all()]
    context = {"status" : "success", "sales_person_all" : [allSalesPersons]}
    return JsonResponse(context)

@csrf_exempt
def ShopDetails(request):
    selectedName = request.POST['PostData'] 
    context = {}
    context['Name']=selectedName
    for name in SalesPerson.objects.filter(name = selectedName):
        context['areaAssign'] = name.areaAssign
    context['shopAddressDetails'] = []
    for addr in ShopAddress.objects.filter(area__icontains = context['areaAssign']):#colName__contains
        shopDetails = {}
        shopDetails['shopName'] = str(addr.shopName),
        shopDetails['shopNumber'] = str(addr.shopNumber),
        shopDetails['ownerName'] = str(addr.ownerName),
        shopDetails['ownerContact'] = str(addr.ownerContact),
        shopDetails['FullAddr'] = ' '.join([str(addr.shopNumber), str(addr.street), str(addr.street), str(addr.area), str(addr.pinCode), str(addr.state)])
        context['shopAddressDetails'].append(shopDetails)

    pprint(context)
    return JsonResponse(context)

@csrf_exempt
def SalesTrackerSaveData(request):
    postData = request.POST['PostData_submit']
    jsonData = json.loads(postData)

    salesPersonName = jsonData['sales_Person']
    location = jsonData['Location']
    shopName = jsonData['selected_Shop']

    itemsList = jsonData['sales_Items']

    for item in itemsList:
        itemSoldName = item[1]
        itemSoldPerPrice = item[2]
        quantity = item[3]
        totalPrice = item[4]
        itemInStock = item[5]
        itemStockRequired = item[6]
        saveData = [salesPersonName,location,shopName,itemSoldName,itemSoldPerPrice,quantity,totalPrice,itemInStock,itemStockRequired]

        newEntry = SalesTracker(salesPersonName=salesPersonName, location=location, shopName=shopName,
                    itemSoldName=itemSoldName, itemSoldPerPrice=itemSoldPerPrice, quantity=quantity,
                    totalPrice=totalPrice, itemInStock=itemInStock, itemStockRequired=itemStockRequired)
        print(saveData)
        newEntry.save()

    return JsonResponse({"status":"Saved Successfully."})
