
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static

from . import views

app_name = 'SalesTrackApp'

urlpatterns = [
    # hompepage
    path('', views.index, name='index'),
    path('SalesTrack/', views.SalesTrack, name='SalesTrack'),
    path('SalesTrack/GETNames/', views.GETNames, name='GETNames'),
    path('SalesTrack/ShopDetails/',  views.ShopDetails, name='ShopDetails'),
    path('SalesTrack/SalesTrackerSaveData/',  views.SalesTrackerSaveData, name='SalesTrackerSaveData'),
]


urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)