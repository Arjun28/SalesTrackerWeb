from django.db import models

class SalesPerson(models.Model):
    name = models.CharField(max_length=25)
    isActive = models.BooleanField(default=True)
    contactNumber = models.CharField(max_length=15)
    areaAssign = models.CharField(max_length=30)
    date_added = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

class ShopAddress(models.Model):
    shopName = models.CharField(max_length=25)
    shopNumber = models.CharField(max_length=10)
    ownerName = models.CharField(max_length=25)
    ownerContact = models.CharField(max_length=15)
    street = models.CharField(max_length=15)
    area = models.CharField(max_length=25)
    pinCode = models.CharField(max_length=10)
    state = models.CharField(max_length=15)
    dateCreated = models.DateTimeField(auto_now_add=True)
    isActive = models.BooleanField(default=True)

    def __str__(self):
        return self.shopName

class SalesTracker(models.Model):
    salesPersonName = models.CharField(max_length=25)
    dateAdded = models.DateTimeField(auto_now_add=True)
    location = models.CharField(max_length=100)
    shopName = models.CharField(max_length=25)
    itemSoldName = models.CharField(max_length=25)
    itemSoldPerPrice = models.FloatField()
    quantity = models.FloatField()
    totalPrice = models.FloatField()
    itemInStock = models.FloatField()
    itemStockRequired = models.FloatField()

    def __str__(self):
        return self.salesPersonName