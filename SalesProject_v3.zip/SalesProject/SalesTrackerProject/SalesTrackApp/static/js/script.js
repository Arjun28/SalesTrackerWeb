$(document).ready(function(){
    //Get names and populate the dropdown 
    $.ajax({
        url: 'GETNames/',
        method:  "GET",
        data: {},
        success: function(resultResponse){
            let namesList = resultResponse.sales_person_all;
            for(let i=0; i<namesList[0].length; i++){
                $("#SalesManSelect").append("<option value="+namesList[0][i]+">"+namesList[0][i]+"</option>");
            }
        }

    });

    //Get products and populate the dropdown 
    $.ajax({
        url: 'GETAllProducts/',
        method:  "GET",
        data: {},
        success: function(resultResponse){
            let productCodesList = resultResponse.product_codes_all[0];
            for(let i=0; i<productCodesList.length - 18; i++){
                let markup = "<tr><th>"+productCodesList[i]+"</th>\
                                    <td><input type='number' step='1' class='form-control input-sm' id="+productCodesList[i]+"></td>\
                                    <td><input type='number' step='1' class='form-control input-sm' id="+productCodesList[i]+"></td>\
                              </tr>";
                $("#salesInput tbody").append(markup);
            }
        }
    });

    

    let SubmitData = {"sales_Person" : "", "selected_Shop" : "", "Location" : "", "sales_Items" : null}; //Final Data preparation


    $("#SalesManSelect").change(function() {
        // .empty() will keep the unique area names. else area names will be appended with every time when salesman is selected.
        $("#BeatList").empty()
        //after .empty() add one Default select tag 
        $("#BeatList").append("<option value='selected'>--Select Beat Area--</option>")
        let selectedName = $("#SalesManSelect option:selected").text();
        SubmitData.sales_Person = selectedName;//final data
        //console.log(selectedName);
        //get the beat list and populate the dropdown - Beat List
        if($("#SalesManSelect").val()!=='select'){
            $.ajax({
                url: 'GETBeatArea/',
                method:  "GET",
                data: {  
                    PostData : selectedName,    
                },
                success: function(resultResponse){
                    //console.log(resultResponse);
                    let beatAreaNames = resultResponse.AssignedBeatAreas;
                    for(let i=0; i<beatAreaNames.length; i++){ 
                        $("#BeatList").append("<option value="+beatAreaNames[i]+">"+beatAreaNames[i]+"</option>")
                    }
                }
            });
        }
    });


    
    $("#BeatList").change(function() {
        // .empty() will keep the unique area names. else area names will be appended with every time when salesman is selected.
        $("#ShopName").empty();
        //after .empty() add one Default select tag 
        $("#ShopName").append("<option value='selected'>--Select Shop--</option>")
        let selectedArea= $("#BeatList option:selected").text();
        //console.log(selectedArea);
        //Get data and populate the dropdown
        $.ajax({
            url: 'ShopDetails/',
            method:  "GET",
            data: {  
                PostData : selectedArea,    
            },
            success: function(resultResponse){
                //console.log(resultResponse)
                let areaAssign = resultResponse.areaName;
                let shopAddressDetails = resultResponse.shopAddressDetails;
                shopDetailsList = []
                for(let i=0; i<shopAddressDetails.length; i++){
                    shopName = shopAddressDetails[i].shopName;
                    $("#ShopName").append("<option value="+shopName+">"+shopName+"</option>")
                    shopDetailsList.push(shopAddressDetails[i])
                }

                //console.log(shopDetailsList);

                $("#ShopName").change(function(){
                    //console.log(shopDetailsList.length)
                    let selectedShop = $("#ShopName option:selected").text();
                    SubmitData.selected_Shop = selectedShop;//final data
                    //console.log("-->, " + selectedShop);
                    for(x=0;x<shopDetailsList.length;x++){                            
                        if(selectedShop === shopDetailsList[x].shopName[0]){
                            //console.log(shopDetailsList[x].shopName[0]);
                            $("#ShopOwner").text(shopDetailsList[x].ownerName[0]);
                            $("#Shopcontact").text(shopDetailsList[x].ownerContact[0]);
                            $("#ShopAddress").text(shopDetailsList[x].FullAddr)
                        }
                    }
                    SubmitData.Location = $("#ShopAddress").text();//final data                       
                });
            }
        });
    });



    //clear InputTable data
    $("#SalesClearClick").click(function(){
        $("#salesInput input[type=number]").val('');
        $("#salesInput input[type=text]").val('');
    }); 


    $("#submitData").click(function(){
        //console.log(SubmitData);
        let submitTableDataItemDetails = []
        $('#salesInput tr').each(function(){
            let row = {}
            itemName =  $(this).text().trim();
            row.itemName = itemName;
            row.data = [];
            $(this).find('input').each(function(){
                row.data.push($(this).val());
            })
            submitTableDataItemDetails.push(row);
        });
        submitTableDataItemDetails.shift(); 
        //console.log(submitTableDataItemDetails);

        SubmitData.sales_Items = submitTableDataItemDetails;//final data  
        console.log((SubmitData));  

        $.ajax({
            url: 'SalesTrackerSaveData/',
            method:  "POST",
            data: {  
                PostData_submit : JSON.stringify(SubmitData),    
            },
            success: function(resultResponse){
                alert("Data Submitted");
            }
        });

    });

});

