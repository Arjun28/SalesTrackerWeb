
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static


from . import views

app_name = 'SalesTrackApp'

urlpatterns = [
    # hompepage
    path('', views.index, name='index'),
    path('SalesTrack/', views.SalesTrack, name='SalesTrack'),
    path('SalesTrack/GETNames/', views.GETNames, name='GETNames'),
    path('SalesTrack/GETAllProducts/', views.GETAllProducts, name='GETAllProducts'),
    path('SalesTrack/GETBeatArea/', views.GETBeatArea, name='GETBeatArea'), 
    path('SalesTrack/ShopDetails/',  views.ShopDetails, name='ShopDetails'),
    path('SalesTrack/SalesTrackerSaveData/',  views.SalesTrackerSaveData, name='SalesTrackerSaveData'),

    path('SalesDetails/',  views.SalesDetails, name='SalesDetails'),
    path('SalesDetails/GETNames/', views.GETNames, name='GETNames'),
    path('SalesDetails/getDataForDates/', views.getDataForDates, name='getDataForDates'),
]

if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)