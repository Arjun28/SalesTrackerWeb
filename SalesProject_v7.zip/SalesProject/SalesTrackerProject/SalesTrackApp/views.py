from datetime import datetime
from django.shortcuts import redirect, render
from django.http import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json, csv, os
from SalesTrackApp.models import SalesPerson, ShopAddress, SalesTracker, Products
from django.conf import settings #for the Media ROOT folder | helps consider full path on server and write project folder's media folder
from pprint import pprint
import warnings

warnings.simplefilter(action='ignore', category=RuntimeWarning)


def index(request):
    return HttpResponse("Welcome....")

def SalesTrack(request):
    return render(request, 'SalesTrackApp/SalesTracker.html')

@csrf_exempt
def GETNames(request):
    allSalesPersons = list(set([s_person.name for s_person in SalesPerson.objects.all()]))
    context = {"status" : "success", "sales_person_all" : [allSalesPersons]}
    return JsonResponse(context)

@csrf_exempt
def GETAllProducts(request):
    allProducts = list(set([productCode.productCode for productCode in Products.objects.all()]))
    context = {"status" : "success", "product_codes_all" : [allProducts]}
    return JsonResponse(context)


@csrf_exempt
def GETBeatArea(request):
    selectedName = request.GET['PostData']
    context = {}
    context['Name']=selectedName
    context['AssignedBeatAreas'] = []
    for areaName in SalesPerson.objects.filter(name = selectedName):
        context['AssignedBeatAreas'].append(areaName.areaAssign)
    return JsonResponse(context)


def ShopDetails(request):
    selectedArea= request.GET['PostData'] 
    context = {}
    context['areaName']=selectedArea
    context['shopAddressDetails'] = []
    for addr in ShopAddress.objects.filter(area__icontains = context['areaName'].strip()):#colName__contains
        shopDetails = {}
        shopDetails['shopName'] = str(addr.shopName),
        shopDetails['shopNumber'] = str(addr.shopNumber),
        shopDetails['ownerName'] = str(addr.ownerName),
        shopDetails['ownerContact'] = str(addr.ownerContact),
        shopDetails['FullAddr'] = ', '.join([str(addr.shopNumber), str(addr.street), str(addr.area), str(addr.pinCode), str(addr.state)])
        context['shopAddressDetails'].append(shopDetails)
    return JsonResponse(context)    


@csrf_exempt
def SalesTrackerSaveData(request):
    postData = request.POST['PostData_submit']
    jsonData = json.loads(postData)

    salesPersonName = jsonData['sales_Person']
    location = jsonData['Location']
    shopName = jsonData['selected_Shop']
    itemsList = jsonData['sales_Items']

    print(salesPersonName,location,shopName,itemsList)

    context = {"status":"Saved Successfully"}

    try:
        for item in itemsList:
            itemName = item['itemName']      
            itemInStock = item['data'][0]
            itemRequired = item['data'][1]
            saveData = [salesPersonName,location,shopName,itemName,itemInStock,itemRequired]
            #print(saveData)
            newEntry = SalesTracker(salesPersonName=salesPersonName, location=location, shopName=shopName,
                        itemSoldName=itemName, itemInStock=itemInStock, itemStockRequired=itemRequired)
            newEntry.save()
    except(ValueError):
        context = {"status":"Saved Successfully"}
    else:
        context = {"status":"Unsuccessful"}        

    return JsonResponse(context)

"""
@csrf_exempt
def SalesTrackerSaveData(request):
    postData = request.POST['PostData_submit']
    jsonData = json.loads(postData)

    salesPersonName = jsonData['sales_Person']
    location = jsonData['Location']
    shopName = jsonData['selected_Shop']

    itemsList = jsonData['sales_Items']

    for item in itemsList:
        itemSoldName = item[1]
        itemSoldPerPrice = item[2]
        quantity = item[3]
        totalPrice = item[4]
        itemInStock = item[5]
        itemStockRequired = item[6]
        saveData = [salesPersonName,location,shopName,itemSoldName,itemSoldPerPrice,quantity,totalPrice,itemInStock,itemStockRequired]

        newEntry = SalesTracker(salesPersonName=salesPersonName, location=location, shopName=shopName,
                    itemSoldName=itemSoldName, itemSoldPerPrice=itemSoldPerPrice, quantity=quantity,
                    totalPrice=totalPrice, itemInStock=itemInStock, itemStockRequired=itemStockRequired)
        print(saveData)
        newEntry.save()

    return JsonResponse({"status":"Saved Successfully."})
"""


def SalesDetails(request):
    return render(request, 'SalesTrackApp/SalesDetails.html')

@csrf_exempt
def getDataForDates(request):
    FromDate = request.GET['FromDate']
    ToDate = request.GET['ToDate']
    SalesPerson = request.GET['SalesPerson']
    #fromDate = datetime.strptime(FromDate, '%Y-%m-%d').strftime('%Y-%m-%d')
    #toDate = datetime.strptime(ToDate, '%Y-%m-%d').strftime('%Y-%m-%d')

    print(FromDate, ToDate)

    context = {}

    if(SalesPerson!=''):#when SalesPerson is selected
        print("SalesPerson is selected")
        if(FromDate == ToDate):
            salesDetails = SalesTracker.objects.filter(salesPersonName = SalesPerson, dateAdded__icontains = FromDate)
            print("From-date and To-Date are same.")
        else:
            salesDetails = SalesTracker.objects.filter(salesPersonName = SalesPerson, dateAdded__gte=FromDate, dateAdded__lte=ToDate)
            print("From-date and To-Date are not same.")
        dataset = []
        for sdrow in salesDetails:
            #print([sdrow.salesPersonName, sdrow.shopName, sdrow.location, sdrow.itemSoldName, sdrow.dateAdded])
            dataset.append([sdrow.salesPersonName, sdrow.shopName, sdrow.location, sdrow.itemSoldName, sdrow.itemStockRequired, sdrow.dateAdded])
        outFileName = os.path.join(settings.MEDIA_ROOT, str("Report" + datetime.now().strftime('_%Y%m%d%H%M%S_%f') + '.csv'))
        outFile = open(outFileName,'w', newline='' )
        outfile_writer = csv.writer(outFile)
        dataset.insert(0,['SalesPersonName', 'ShopName', 'Location', 'itemOrdered', 'itemStockOrdered', 'RecordDate'])
        outfile_writer.writerows(dataset)
        outFile.close()

        context['status'] = "success"
        context['downloadFilePath'] = str(outFileName.split('\\')[-2] + '\\' +outFileName.split('\\')[-1]) # windows server - '\\' | linux - str(outFileName.split('/')[-2] + '/' +outFileName.split('/')[-1])


    else:#when SalesPerson is not selected.
        print("SalesPerson is not selected")
        if(FromDate == ToDate):
            salesDetails = SalesTracker.objects.filter(dateAdded__icontains = FromDate)
            print("From-date and To-Date are same.")
        else:
            salesDetails = SalesTracker.objects.filter(dateAdded__gte=FromDate, dateAdded__lte=ToDate)
            print("From-date and To-Date are not same.")
        dataset = []
        for sdrow in salesDetails:
            #print([sdrow.salesPersonName, sdrow.shopName, sdrow.location, sdrow.itemSoldName, sdrow.dateAdded])
            dataset.append([sdrow.salesPersonName, sdrow.shopName, sdrow.location, sdrow.itemSoldName, sdrow.itemStockRequired, sdrow.dateAdded])
        outFileName = os.path.join(settings.MEDIA_ROOT, str("Report" + datetime.now().strftime('_%Y%m%d%H%M%S_%f') + '.csv'))
        outFile = open(outFileName,'w', newline='' )
        outfile_writer = csv.writer(outFile)
        dataset.insert(0,['SalesPersonName', 'ShopName', 'Location', 'itemOrdered', 'itemStockOrdered', 'RecordDate'])
        outfile_writer.writerows(dataset)
        outFile.close()

        context['status'] = "success"
        context['downloadFilePath'] = str(outFileName.split('\\')[-2] + '\\' +outFileName.split('\\')[-1]) # windows server - '\\' | linux - str(outFileName.split('/')[-2] + '/' +outFileName.split('/')[-1])
    print(context)
    return JsonResponse(context)

