$(document).ready(function(){

    //Get names and populate the dropdown 
    $.ajax({
        url: 'GETNames/',
        method:  "GET",
        data: {},
        success: function(resultResponse){
            let namesList = resultResponse.sales_person_all;
            for(let i=0; i<namesList[0].length; i++){
                $("#SalesManSelect").append("<option value="+namesList[0][i]+">"+namesList[0][i]+"</option>");
                //console.log(namesList[0][i])
            }
        }

    });



    let fromDate = '';
    let toDate = '';
    let salesPerson = '';

    $('#dateFromSelected').change(function() {
        let dateFromSelect = $('#dateFromSelected').val();   
        fromDate = dateFromSelect;
    });

    $('#dateToSelected').change(function() {
        let dateToSelect = $('#dateToSelected').val();   
        toDate = dateToSelect;
    });

    $('#SalesManSelect').change(function() {
        let SalesManSelect= $("#SalesManSelect option:selected").text();   
        salesPerson = SalesManSelect;
    });


    $("#submitData").click(function(){
        $('#downloadbutton').attr("disabled", true);
        $('#downloadform').attr('action', '');

        if(fromDate != ''){
            alert("You are fetching details for Dates : \n From " +fromDate+ " To " +toDate+ " \nFor " +salesPerson);
            let fDate = parseInt(fromDate.split('-').join(''));
            let tDate = parseInt(toDate.split('-').join(''));

            if((salesPerson != '--Select Name--') & (fDate < tDate) || (fDate == tDate)){
            //#console.log("Date is correct. f<t or f=t.")

                $.ajax({
                    url: 'getDataForDates/',
                    method:  "GET",
                    data: {  
                        FromDate : fromDate, 
                        ToDate   : toDate,
                        SalesPerson : salesPerson,
                    },
                    success: function(resultResponse){
                        let thisSite = window.location.href;
                        let thisSite_list = thisSite.split('/');
                        //console.log(thisSite_list)
                        thisSite_list.splice(3,1)
                        let downloadURL = thisSite_list.join('\\')
                        //console.log("downloadURL : " +downloadURL);
                        ///console.log("downloadFilePath : " +resultResponse.downloadFilePath);
                        console.log(downloadURL + resultResponse.downloadFilePath)
                        $('#downloadbutton').attr("disabled", false);
                        $('#downloadform').attr('action', downloadURL + resultResponse.downloadFilePath);
                    }
                });

            }
            else{
                alert("Date is NOT correct. f>t")
            }

        }

        else{
            alert("Please input atleast From Date \n From " +fromDate+ " To " +toDate);
        }
    });


});
