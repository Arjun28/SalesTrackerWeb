from django.contrib import admin

from .models import SalesPerson, ShopAddress, SalesTracker, Products

admin.site.register(SalesPerson)
admin.site.register(ShopAddress)
admin.site.register(SalesTracker)
admin.site.register(Products)