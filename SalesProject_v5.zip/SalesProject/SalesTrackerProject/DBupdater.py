#!/usr/bin/python
# -*- coding: <encoding name> -*-

import sqlite3, csv
from datetime import datetime

conn = sqlite3.connect('db.sqlite3')
cur = conn.cursor()


inFile = open('shopAddress.csv','r')
inFileReader = csv.reader(inFile)
shopAddressList= list(inFileReader)

#FOR SHOP-ADDRESS
#records or rows in a list
# get the id number from DB and populate id+1     '2021-08-29 16:42:32.953683'
records = []
for row in shopAddressList[1:]:
    id = row[0]
    shopName = row[1]#Customer Name
    shopNumber	= row[2]#CustomerID
    ownerName	= row[3]#Owner Name
    ownerContact =	row[4]#Cell Number
    street = row[5]#Land Mark
    area	= row[6]#beat name 
    pinCode	= ''
    state	= row[7]#Villege Name
    dateCreated	 = datetime.now()
    isActive = row[8]
    print(id,shopName,shopNumber,ownerName,ownerContact,street,area,pinCode,dateCreated,isActive,state)
    rowInsert = [id,shopName,shopNumber,ownerName,ownerContact,street,area,pinCode,dateCreated,isActive,state]
    records.append(rowInsert)
#insert multiple records in a single query
cur.executemany('INSERT INTO SalesTrackApp_shopaddress VALUES(?,?,?,?,?,?,?,?,?,?,?);',records)

print('We have inserted ', cur.rowcount, ' records to the table.')

"""

#FOR SalesMan-BeatList

inFile = open('salesMan_BeatList 2.csv','r')
inFileReader = csv.reader(inFile)
salesMan_beatList = list(inFileReader)

#records or rows in a list
# get the id number from DB and populate id+1     '2021-08-29 16:42:32.953683'
records = []
for row in salesMan_beatList[1:]:
    id = row[0]
    name = row[1]
    isActive = row[2]
    phno = row[3]
    dateAdded = datetime.now()
    beatArea = row[4]
    rowInsert = [id,name,isActive,phno,dateAdded,beatArea]
    print(rowInsert)
    records.append(rowInsert)


#insert multiple records in a single query
cur.executemany('INSERT INTO SalesTrackApp_salesperson VALUES(?,?,?,?,?,?);',records)


print('We have inserted ', cur.rowcount, ' records to the table.')

"""

#commit the changes to db			
conn.commit()
#close the connection
conn.close()





#(34,'Ranga','2021-08-29 16:42:32.953683','13/7 33rd Cross Road Marathahalli 560334 Karnataka', 'XYZ Pastry', 'NC', None,  None,  None,	11.0, 1.0)