$(document).ready(function(){

    //Get names and populate the dropdown
    $.ajax({
        url: 'GETNames/',
        method:  "GET",
        data: {},
        success: function(resultResponse){
            namesList = resultResponse.sales_person_all;
            for(let i=0; i<namesList[0].length; i++){
                $("#SalesManSelect").append("<option value="+namesList[0][i]+">"+namesList[0][i]+"</option>");
            }
        }

    });





    //get the selected name and post to endpoint. Then update the repsonse data to HTML document
	$("#SalesManSelect").change(function() {
        //clear content in dropdown
        $("#ShopName").empty().append("<option value=select>Select Shop Name</option>");
		// var selectedVal = $("#myselect option:selected").text();
		let selectedName = $("#SalesManSelect option:selected").text();
		console.log("Hi, " + selectedName);
        if($("#SalesManSelect").val()!=='select'){
        //Get names and populate the dropdown
            $.ajax({
                url: 'ShopDetails/',
                method:  "POST",
                data: {  
                    PostData : selectedName,    
                },
                success: function(resultResponse){
                    console.log(resultResponse)
                    let Name = resultResponse.Name;
                    let areaAssign = resultResponse.areaAssign;
                    let shopAddressDetails = resultResponse.shopAddressDetails;
                    $("#BeatList").text(areaAssign);
                    shopDetailsList = []
                    //Append to dropdown
                    for(let i=0; i<shopAddressDetails.length; i++){
                        shopName = shopAddressDetails[i].shopName;
                        $("#ShopName").append("<option value="+shopName+">"+shopName+"</option>")
                        shopDetailsList.push(shopAddressDetails[i])
                    }

                    console.log(shopDetailsList);

                    $("#ShopName").change(function(){
                        console.log(shopDetailsList.length)
                        let selectedShop = $("#ShopName option:selected").text();
                        console.log("-->, " + selectedShop);
                        for(x=0;x<shopDetailsList.length;x++){                            
                            if(selectedShop === shopDetailsList[x].shopName[0]){
                                console.log(shopDetailsList[x].shopName[0]);
                                $("#ShopOwner").text(shopDetailsList[x].ownerName[0]);
                                $("#Shopcontact").text(shopDetailsList[x].ownerContact[0]);
                                $("#ShopAddress").text(shopDetailsList[x].FullAddr)
                            }
                        }                           

                    });
                }       
            });
        }
        else{
            alert("Select Salesman Name");
        }

	});


    let ItemRowCounter = 1;

    $("#SalesAdderClick").click(function(){
        let ITEM_NAME = $("#inputDataITEMNAME").val();
        let ITEM_PRICE = $("#inputDataITEMPRICE").val();
        let QUANTITY = $("#inputDataQUANTITY").val();
        let TOTAL_PRICE = $("#inputDataTOTALPRICE").val();
        let ITEM_InStock = $("#inputDataInStock").val();
        let ITEM_StockRequired = $("#inputDataStockRequired").val();

        let tableRow = "<tr id="+ItemRowCounter+"_row>\
            <td>"+ItemRowCounter+"</td>\
            <td>"+ITEM_NAME+"</td>\
            <td>"+ITEM_PRICE+"</td>\
            <td>"+QUANTITY+"</td>\
            <td>"+TOTAL_PRICE+"</td>\
            <td>"+ITEM_InStock+"</td>\
            <td>"+ITEM_StockRequired+"</td>\
            </tr>";
        $("#salesTable").append(tableRow);
        ItemRowCounter+=1;
        console.log(ItemRowCounter);
    });

    $("#SalesClearClick").click(function(){
        $("#salesInput input[type=number]").val('');
        $("#salesInput input[type=text]").val('');
    });

    $("#SalesDeleteClick").click(function(){
        let rowNo = $("#SalesDeleteRow").val();
        let rowNoID = "#"+rowNo+ "_row";
        console.log($(rowNoID));
        $(rowNoID).closest('tr').remove()
    });

//salesTable
    $("#submitData").click(function(){
        let submitTableData = []
        $('#salesTable tr').each(function(){
            let row = []
            $(this).find('td').each(function(){
                row.push($(this).text());
            })
            submitTableData.push(row);
        })  
        submitTableData.shift();
        console.log(submitTableData);            
    });

        



});

