from django.contrib import admin

from .models import SalesPerson, ShopAddress, SalesTracker

admin.site.register(SalesPerson)
admin.site.register(ShopAddress)
admin.site.register(SalesTracker)