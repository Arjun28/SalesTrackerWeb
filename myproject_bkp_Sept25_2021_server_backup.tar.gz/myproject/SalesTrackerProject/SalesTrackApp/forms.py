from django import forms
from .models import ShopAddress

class ShopAddrForm(forms.ModelForm):
    class Meta:
        model = ShopAddress
        fields = ['ownerName','ownerContact','shopNumber','shopNumber','street','area','pinCode','state']
