$(document).ready(function(){

    //Get names and populate the dropdown
    $.ajax({
        url: 'GETNames/',
        method:  "GET",
        data: {},
        success: function(resultResponse){
            namesList = resultResponse.sales_person_all;
            for(let i=0; i<namesList[0].length; i++){
                $("#SalesManSelect").append("<option value="+namesList[0][i]+">"+namesList[0][i]+"</option>");
            }
        }

    });



    let SubmitData = {"sales_Person" : "", "selected_Shop" : "", "Location" : "", "sales_Items" : null}; //Final Data preparation

    //get the selected name and post to endpoint. Then update the repsonse data to HTML document
	$("#SalesManSelect").change(function() {
        //clear content in dropdown and append
        $("#ShopName").empty().append("<option value=select>Select Shop Name</option>");
		// var selectedVal = $("#myselect option:selected").text();
		let selectedName = $("#SalesManSelect option:selected").text();
        SubmitData.sales_Person = selectedName;//final data
		console.log("Hi, " + selectedName);
        if($("#SalesManSelect").val()!=='select'){
        //Get names and populate the dropdown
            $.ajax({
                url: 'ShopDetails/',
                method:  "POST",
                data: {  
                    PostData : selectedName,    
                },
                success: function(resultResponse){
                    console.log(resultResponse)
                    let Name = resultResponse.Name;
                    let areaAssign = resultResponse.areaAssign;
                    let shopAddressDetails = resultResponse.shopAddressDetails;
                    $("#BeatList").text(areaAssign);
                    shopDetailsList = []
                    //Append to dropdown
                    for(let i=0; i<shopAddressDetails.length; i++){
                        shopName = shopAddressDetails[i].shopName[0];
                        $("#ShopName").append("<option value="+shopName+">"+shopName+"</option>")
                        shopDetailsList.push(shopAddressDetails[i])
                    }

                    console.log(shopDetailsList);

                    $("#ShopName").change(function(){
                        console.log(shopDetailsList.length)
                        let selectedShop = $("#ShopName option:selected").text();
                        SubmitData.selected_Shop = selectedShop;//final data
                        console.log("-->, " + selectedShop);
                        for(x=0;x<shopDetailsList.length;x++){                            
                            if(selectedShop === shopDetailsList[x].shopName[0]){
                                console.log(shopDetailsList[x].shopName[0]);
                                $("#ShopOwner").text(shopDetailsList[x].ownerName[0]);
                                $("#Shopcontact").text(shopDetailsList[x].ownerContact[0]);
                                $("#ShopAddress").text(shopDetailsList[x].FullAddr)
                            }
                        }

                        SubmitData.Location = $("#ShopAddress").text();//final data                           

                    });
                }       
            });
        }
        else{
            alert("Select Salesman Name");
        }

	});


    let ItemRowCounter = 1;

    $("#SalesAdderClick").click(function(){
        
        let ITEM_NAME = $("#inputDataITEMNAME").val();
        let ITEM_PRICE = $("#inputDataITEMPRICE").val();
        let QUANTITY = $("#inputDataQUANTITY").val();
        let TOTAL_PRICE = $("#inputDataTOTALPRICE").val();
        let ITEM_InStock = $("#inputDataInStock").val();
        let ITEM_StockRequired = $("#inputDataStockRequired").val();

        let tableRow = "<tr id="+ItemRowCounter+"_row>\
            <td>"+ItemRowCounter+"</td>\
            <td>"+ITEM_NAME+"</td>\
            <td>"+ITEM_PRICE+"</td>\
            <td>"+QUANTITY+"</td>\
            <td>"+TOTAL_PRICE+"</td>\
            <td>"+ITEM_InStock+"</td>\
            <td>"+ITEM_StockRequired+"</td>\
            </tr>";
        $("#salesTable").append(tableRow);
        ItemRowCounter+=1;
        console.log(ItemRowCounter);
    });
    
    //clear InputTable data
    $("#SalesClearClick").click(function(){
        $("#salesInput input[type=number]").val('');
        $("#salesInput input[type=text]").val('');
    });

    //Delete row
    $("#SalesDeleteClick").click(function(){
        let rowNo = $("#SalesDeleteRow").val();
        let rowNoID = "#"+rowNo+ "_row";
        console.log($(rowNoID));
        $(rowNoID).closest('tr').remove()
    });


    //salesTable
    let sales_Person_Name = $("#SalesManSelect option:selected").text();
    
    $("#submitData").click(function(){
        let submitTableDataItemDetails = []
        $('#salesTable tr').each(function(){
            let row = []
            $(this).find('td').each(function(){
                row.push($(this).text());
            })
            submitTableDataItemDetails.push(row);
        })  
        submitTableDataItemDetails.shift();
        console.log(submitTableDataItemDetails);

        SubmitData.sales_Items = submitTableDataItemDetails;//final data  
        console.log(JSON.stringify(SubmitData));  
        
        $.ajax({
            url: 'SalesTrackerSaveData/',
            method:  "POST",
            data: {  
                PostData_submit : JSON.stringify(SubmitData),    
            },
            success: function(resultResponse){
                alert("Data Saved Successfully!");
            }
        });

    });


        



});

